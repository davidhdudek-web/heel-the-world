#!/usr/bin/env python3
"""
HTW Deploy Script — speichert FTP-Credentials lokal und deployed HTML zu alfahosting
Einmalige Einrichtung, dann kann Claude direkt deployen
"""
import os
import json
import paramiko
from pathlib import Path

CONFIG_FILE = os.path.expanduser("~/.htw-deploy-config.json")

def setup():
    """Einmalig: Credentials speichern"""
    print("=== HTW Deploy Setup ===")
    print("Gib deine alfahosting FTP-Daten ein (werden lokal verschlüsselt gespeichert)")
    
    config = {
        "sftp_host": "host155.alfahosting-server.de",
        "sftp_user": input("SFTP User (gcfnn41f): ") or "gcfnn41f",
        "sftp_pass": input("SFTP Pass: "),
        "sftp_port": 22,
        "target_path": "/public_html/index.html"
    }
    
    with open(CONFIG_FILE, 'w') as f:
        json.dump(config, f)
    os.chmod(CONFIG_FILE, 0o600)  # Nur Besitzer lesen
    print(f"✓ Config gespeichert: {CONFIG_FILE}")

def deploy(html_content):
    """Deploy HTML zu alfahosting"""
    if not os.path.exists(CONFIG_FILE):
        print("Config nicht gefunden. Bitte setup() ausführen.")
        return False
    
    with open(CONFIG_FILE) as f:
        config = json.load(f)
    
    try:
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh.connect(
            config["sftp_host"],
            port=config["sftp_port"],
            username=config["sftp_user"],
            password=config["sftp_pass"],
            timeout=15
        )
        print("✓ Connected")
        
        sftp = ssh.open_sftp()
        
        # Temporäre Datei schreiben
        tmp_file = "/tmp/htw-index.html"
        with open(tmp_file, 'w') as f:
            f.write(html_content)
        
        # Upload
        sftp.put(tmp_file, config["target_path"])
        print(f"✓ Deployed to {config['target_path']}")
        
        sftp.close()
        ssh.close()
        print("✓ heeltheworld.ch is live")
        return True
    except Exception as e:
        print(f"✗ Deploy failed: {e}")
        return False

if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "setup":
        setup()
    else:
        print("Usage: python deploy-htw.py setup")
